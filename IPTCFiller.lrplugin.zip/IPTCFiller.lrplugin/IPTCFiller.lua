local LrApplication = import "LrApplication"
local LrDialogs = import "LrDialogs"
local LrPathUtils = import "LrPathUtils"
local LrTasks = import "LrTasks"
local LrView = import "LrView"
local LrBinding = import "LrBinding"
local LrFunctionContext = import "LrFunctionContext"
local LrProgressScope = import "LrProgressScope"

local scriptPath = LrPathUtils.child(
    LrPathUtils.child(LrPathUtils.getStandardFilePath("home"), "LightroomAI"),
    "iptc_filler.py"
)

local function selectMode()
    local mode = nil
    LrFunctionContext.callWithContext("ModeSelector", function(context)
        local f = LrView.osFactory()
        local props = LrBinding.makePropertyTable(context)
        props.mode = "review"
        local contents = f:column {
            bind_to_object = props,
            spacing = f:dialog_spacing(),
            f:static_text {
                title = "How would you like to run IPTCFiller?",
                font = "<system/bold>",
            },
            f:radio_button {
                title = "Review & Select - check each field before applying",
                value = LrView.bind("mode"),
                checked_value = "review",
            },
            f:radio_button {
                title = "Auto (No Prompts) - fill all fields instantly",
                value = LrView.bind("mode"),
                checked_value = "auto",
            },
        }
        local result = LrDialogs.presentModalDialog {
            title = "IPTCFiller",
            contents = contents,
            actionVerb = "Continue",
            cancelVerb = "Cancel",
        }
        if result == "ok" then
            mode = props.mode
        end
    end)
    return mode
end

local function getGPS(photo)
    local gps = photo:getRawMetadata("gps")
    if gps and gps.latitude and gps.longitude then
        return gps.latitude, gps.longitude
    end
    return nil, nil
end

local function buildCommand(photoPath, lat, lon)
    local command = 'python3 "' .. scriptPath .. '" "' .. photoPath .. '"'
    if lat and lon then
        command = command .. ' "' .. tostring(lat) .. '" "' .. tostring(lon) .. '"'
    end
    return command
end

local function parseData(result)
    local data = {}
    for key, value in result:gmatch('"([^"]+)"%s*:%s*"([^"]*)"') do
        data[key] = value
    end
    return data
end

local function applyMetadata(catalog, photo, data, props, fields)
    catalog:withWriteAccessDo("Fill IPTC Metadata", function()
        if props.check_title and data.title then
            photo:setRawMetadata("title", data.title)
        end
        if props.check_caption and data.caption then
            photo:setRawMetadata("caption", data.caption)
        end
        if props.check_keywords and data.keywords then
            for kw in data.keywords:gmatch("[^,]+") do
                kw = kw:match("^%s*(.-)%s*$")
                if kw and #kw > 0 then
                    local kwObj = catalog:createKeyword(kw, {}, false, nil, true)
                    photo:addKeyword(kwObj)
                end
            end
        end
        if props.check_sublocation and data.sublocation then
            photo:setRawMetadata("location", data.sublocation)
        end
        if props.check_city and data.city then
            photo:setRawMetadata("city", data.city)
        end
        if props.check_county and data.county then
            photo:setRawMetadata("stateProvince", data.county)
        end
        if props.check_country and data.country then
            photo:setRawMetadata("country", data.country)
        end
        if props.check_creator and data.creator then
            photo:setRawMetadata("creator", data.creator)
        end
        if props.check_copyright and data.copyright then
            photo:setRawMetadata("copyright", data.copyright)
            photo:setRawMetadata("copyrightState", "copyrighted")
        end
    end)
end

local function processPhotoReview(catalog, photo, index, total)
    local photoPath = photo:getRawMetadata("path")
    local filename = LrPathUtils.leafName(photoPath)
    local lat, lon = getGPS(photo)
    local command = buildCommand(photoPath, lat, lon)
    local handle = io.popen(command)
    local result = handle:read("*a")
    handle:close()
    result = result:match("^%s*(.-)%s*$")
    if not result or #result == 0 then
        LrDialogs.message("IPTCFiller", "No data returned for " .. filename, "warning")
        return
    end
    local data = parseData(result)
    if not next(data) then
        LrDialogs.message("IPTCFiller", "Could not parse data for " .. filename, "warning")
        return
    end
    local applied = 0
    LrFunctionContext.callWithContext("IPTCDialog", function(context)
        local f = LrView.osFactory()
        local props = LrBinding.makePropertyTable(context)
        local fields = {
            { key = "title",       label = "Title" },
            { key = "caption",     label = "Caption" },
            { key = "keywords",    label = "Keywords" },
            { key = "category",    label = "Category" },
            { key = "sublocation", label = "Sublocation" },
            { key = "city",        label = "City" },
            { key = "county",      label = "County" },
            { key = "country",     label = "Country" },
            { key = "creator",     label = "Creator" },
            { key = "copyright",   label = "Copyright" },
        }
        for _, item in ipairs(fields) do
            props["check_" .. item.key] = (data[item.key] ~= nil and #data[item.key] > 0)
        end
        local rows = {
            spacing = f:dialog_spacing(),
            bind_to_object = props,
            f:static_text {
                title = "Photo " .. index .. " of " .. total .. ": " .. filename,
                font = "<system/bold>",
            },
            f:static_text {
                title = "Tick the fields you want to apply:",
            },
        }
        for _, item in ipairs(fields) do
            local value = data[item.key] or ""
            if #value > 0 then
                local display = value
                if #display > 60 then display = display:sub(1, 60) .. "..." end
                rows[#rows + 1] = f:row {
                    f:checkbox {
                        title = item.label .. ":",
                        value = LrView.bind("check_" .. item.key),
                        width = 120,
                    },
                    f:static_text {
                        title = display,
                        width = 340,
                    },
                }
            end
        end
        rows[#rows + 1] = f:row {
            f:push_button {
                title = "Select All",
                action = function()
                    for _, item in ipairs(fields) do
                        if data[item.key] and #data[item.key] > 0 then
                            props["check_" .. item.key] = true
                        end
                    end
                end,
            },
            f:push_button {
                title = "Select None",
                action = function()
                    for _, item in ipairs(fields) do
                        props["check_" .. item.key] = false
                    end
                end,
            },
        }
        local result2 = LrDialogs.presentModalDialog {
            title = "IPTCFiller Suggested Metadata",
            contents = f:column(rows),
            actionVerb = "Apply",
            cancelVerb = "Skip",
        }
        if result2 == "ok" then
            applyMetadata(catalog, photo, data, props, fields)
            applied = 1
        end
    end)
    return applied
end

local function processPhotoAuto(catalog, photo)
    local photoPath = photo:getRawMetadata("path")
    local lat, lon = getGPS(photo)
    local command = buildCommand(photoPath, lat, lon)
    local handle = io.popen(command)
    local result = handle:read("*a")
    handle:close()
    result = result:match("^%s*(.-)%s*$")
    if not result or #result == 0 then return end
    local data = parseData(result)
    if not next(data) then return end
    local props = {
        check_title = true, check_caption = true, check_keywords = true,
        check_category = true, check_sublocation = true, check_city = true,
        check_county = true, check_country = true, check_creator = true,
        check_copyright = true
    }
    applyMetadata(catalog, photo, data, props, {})
end

LrTasks.startAsyncTask(function()
    local catalog = LrApplication.activeCatalog()
    local photos = catalog:getTargetPhotos()
    if #photos == 0 then
        LrDialogs.message("IPTCFiller", "Please select at least one photo first.", "info")
        return
    end
    local mode = selectMode()
    if not mode then return end
    if mode == "review" then
        for i, photo in ipairs(photos) do
            local filename = LrPathUtils.leafName(photo:getRawMetadata("path"))
            LrDialogs.message("IPTCFiller", "Analysing " .. i .. " of " .. #photos .. ": " .. filename .. "\n\nPlease wait...", "info")
            processPhotoReview(catalog, photo, i, #photos)
        end
        LrDialogs.message("IPTCFiller", "All done! Processed " .. #photos .. " photo(s).", "info")
    else
        local progress = LrProgressScope {
            title = "IPTCFiller: Analysing " .. #photos .. " photo(s)...",
            functionContext = nil,
        }
        for i, photo in ipairs(photos) do
            if progress:isCanceled() then break end
            local filename = LrPathUtils.leafName(photo:getRawMetadata("path"))
            progress:setCaption("Analysing " .. i .. " of " .. #photos .. ": " .. filename)
            progress:setPortionComplete(i - 1, #photos)
            processPhotoAuto(catalog, photo)
        end
        progress:done()
        LrDialogs.message("IPTCFiller", "All done! Processed " .. #photos .. " photo(s).", "info")
    end
end)
