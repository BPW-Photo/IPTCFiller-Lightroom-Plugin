return {
    LrSdkVersion = 6.0,
    LrSdkMinimumVersion = 5.0,
    LrToolkitIdentifier = "com.lightroomai.iptcfiller",
    LrPluginName = "IPTCFiller",
    LrPluginInfoUrl = "https://www.belfastphotoworkshops.com",
    LrAuthor = "Rob Durston & Claude (Anthropic)",
    LrInitPlugin = nil,
    LrLibraryMenuItems = {
        {
            title = "Fill IPTC Metadata with AI",
            file = "IPTCFiller.lua",
        },
    },
    VERSION = { major=1, minor=0, revision=0 },
}
